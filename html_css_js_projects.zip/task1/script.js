document.querySelector('.button').addEventListener('click', function() {
    alert('Вы нажали на кнопку!');
});
